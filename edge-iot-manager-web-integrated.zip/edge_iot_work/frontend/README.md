# Edge IoT Manager frontend

React + TypeScript + Vite dashboard for the existing C++ Edge IoT runtime.

The frontend does not contain task-allocation or scheduling logic. It reads
runtime state from `/api/*` and sends configuration changes back to the C++
API. See `../docs/WEB_DASHBOARD.md` for the integration flow.

```bash
npm install
npm run dev
```
