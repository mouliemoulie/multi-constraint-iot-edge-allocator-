import { CheckCircle2, Info, Settings2 } from 'lucide-react'
import type { Configuration } from '../types/api'
import { useEffect, useState } from 'react'
import { api } from '../services/api'

type Props = { configuration: Configuration | null; onApplied: (c: Configuration) => void; onError: (message: string) => void }
export function ConfigurationPanel({ configuration, onApplied, onError }: Props) {
  const [automatic, setAutomatic] = useState(configuration?.automatic ?? false)
  const [allocation, setAllocation] = useState(configuration?.allocation_strategy ?? 'multi_constraint')
  const [scheduling, setScheduling] = useState(configuration?.scheduling_algorithm ?? 'edf')
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    if (!saving && configuration) {
      setAutomatic(configuration.automatic)
      if (!configuration.automatic) {
        setAllocation(configuration.allocation_strategy)
        setScheduling(configuration.scheduling_algorithm)
      }
    }
  }, [configuration, saving])

  const apply = async () => {
    setSaving(true)
    try {
      const result = await api.applyConfiguration({ automatic, allocation_strategy: allocation, scheduling_algorithm: scheduling })
      onApplied(result.configuration)
    } catch (error) {
      onError(error instanceof Error ? error.message : 'Configuration update failed.')
    } finally { setSaving(false) }
  }

  return <section className="panel configuration-panel">
    <div className="panel-title-row"><div><h2>Configuration</h2><p>Choose how the system should allocate and schedule tasks</p></div></div>
    <div className="config-grid">
      <div className="config-field"><label>Allocation Strategy <Info size={14}/></label>
        <select disabled={automatic || saving} value={allocation} onChange={e => setAllocation(e.target.value)}>
          <option value="multi_constraint">Multi-Constraint</option><option value="round_robin">Round Robin</option><option value="least_load">Least Load</option><option value="priority_based">Priority Based</option>
        </select><small>Considers CPU, RAM, bandwidth, latency, queue &amp; priority</small>
      </div>
      <div className="config-field"><label>Scheduling Algorithm <Info size={14}/></label>
        <select disabled={automatic || saving} value={scheduling} onChange={e => setScheduling(e.target.value)}>
          <option value="edf">EDF (Earliest Deadline First)</option><option value="round_robin">Round Robin</option><option value="priority_based">Priority Based</option>
        </select><small>Determines which queued task executes next</small>
      </div>
      <div className="config-action"><button onClick={apply} disabled={saving} className="primary-button"><Settings2 size={16}/>{saving ? 'Applying…' : 'Apply Configuration'}</button><div className="applied"><CheckCircle2 size={15}/>Configuration applied by backend</div></div>
      <div className="auto-field"><label><input type="checkbox" checked={automatic} disabled={saving} onChange={e => setAutomatic(e.target.checked)}/> Automatic / Recommended <Info size={14}/></label><div className="auto-help">When enabled, the C++ runtime selects the recommended allocation and scheduling algorithms from current resource state.</div><div className="auto-current">{automatic ? <>Requested: <b>Auto</b> · Current: <b>{configuration?.allocation_strategy_label ?? 'Recommended'}</b> / <b>{configuration?.scheduling_algorithm_label ?? 'Recommended'}</b></> : <>Manual mode: <b>{configuration?.allocation_strategy_label ?? 'Multi-Constraint'}</b> / <b>{configuration?.scheduling_algorithm_label ?? 'EDF'}</b></>}</div></div>
    </div>
  </section>
}
