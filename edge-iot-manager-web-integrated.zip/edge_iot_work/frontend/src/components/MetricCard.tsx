import type { ReactNode } from 'react'

type Props = { label: string; value: string | number; note?: string; icon: ReactNode; tone?: string }
export function MetricCard({ label, value, note, icon, tone = 'blue' }: Props) {
  return <div className="metric-card">
    <div className={`metric-icon ${tone}`}>{icon}</div>
    <div><div className="metric-label">{label}</div><div className="metric-value">{value}</div>{note && <div className="metric-note">{note}</div>}</div>
  </div>
}
