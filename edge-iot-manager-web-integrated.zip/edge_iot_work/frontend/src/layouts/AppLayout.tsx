import { Bell, CalendarDays, ChevronDown, CircleHelp, Clock3, Menu, Network, Settings, LayoutDashboard, Smartphone, Server, ListTodo, Boxes, Timer, Gauge, AlertTriangle, FileText, CloudCog } from 'lucide-react'
import type { ReactNode } from 'react'

const nav = [
  ['Dashboard', LayoutDashboard], ['Devices', Smartphone], ['Edge Nodes', Server], ['Tasks', ListTodo], ['Allocations', Boxes], ['Scheduling', Timer], ['Performance', Gauge], ['Alerts', AlertTriangle], ['Reports', FileText], ['Settings', CloudCog]
] as const

type Props = { page: string; setPage: (page: string) => void; children: ReactNode; backendOnline: boolean }
export function AppLayout({ page, setPage, children, backendOnline }: Props) {
  const now = new Date()
  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark"><Network size={26}/></div><div><div className="brand-name">Edge IoT Manager</div><div className="brand-subtitle">Resource Allocation &amp; Task Scheduling</div></div></div>
      <nav>{nav.map(([name, Icon]) => <button key={name} className={page === name ? 'nav-item active' : 'nav-item'} onClick={() => setPage(name)}><Icon size={18}/><span>{name}</span></button>)}</nav>
      <div className="sidebar-summary"><div className="summary-title">System Summary</div><div><span>Devices</span><b id="side-devices">—</b></div><div><span>Edge Nodes</span><b id="side-edges">—</b></div><div><span>Total Tasks</span><b id="side-tasks">—</b></div><div><span>Active Tasks</span><b id="side-active">—</b></div></div>
      <div className="admin-card"><div className="avatar">A</div><div><b>Admin</b><span>System Administrator</span><small>Live access</small></div></div>
    </aside>
    <main className="main-content">
      <header className="topbar"><button className="menu-button"><Menu size={22}/></button><div className="topbar-spacer"/><div className={backendOnline ? 'live-pill' : 'live-pill offline'}><span/> {backendOnline ? 'Live System' : 'Backend unavailable'}</div><div className="top-item"><Clock3 size={16}/>{now.toLocaleTimeString([], {hour: 'numeric', minute: '2-digit', second: '2-digit'})}</div><div className="top-item"><CalendarDays size={16}/>{now.toLocaleDateString([], {weekday:'short', day:'2-digit', month:'short', year:'numeric'})}</div><button className="icon-button"><Bell size={19}/><i>0</i></button><button className="icon-button"><CircleHelp size={19}/></button><div className="profile"><div className="profile-avatar">A</div><span>Admin</span><ChevronDown size={15}/></div></header>
      <div className="content-area">{children}</div>
    </main>
  </div>
}
