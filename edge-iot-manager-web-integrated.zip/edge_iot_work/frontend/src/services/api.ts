import type { Configuration, EdgeNode, Metrics, Status, Task, ActiveTask } from '../types/api'

const request = async <T>(path: string, init?: RequestInit): Promise<T> => {
  const response = await fetch(path, { headers: { 'Content-Type': 'application/json' }, ...init })
  if (!response.ok) {
    let message = `Request failed (${response.status})`
    try {
      const body = await response.json()
      message = body.error ?? message
    } catch { /* keep generic error */ }
    throw new Error(message)
  }
  return response.json() as Promise<T>
}

export const api = {
  health: () => request<{ ok: boolean; backend: string }>('/api/health'),
  status: () => request<Status>('/api/status'),
  configuration: () => request<Configuration>('/api/configuration'),
  applyConfiguration: (payload: { automatic: boolean; allocation_strategy: string; scheduling_algorithm: string }) =>
    request<{ success: boolean; configuration: Configuration }>('/api/configuration', {
      method: 'PUT', body: JSON.stringify(payload)
    }),
  devices: () => request<Array<Record<string, unknown>>>('/api/devices'),
  edgeNodes: () => request<EdgeNode[]>('/api/edge-nodes'),
  tasks: () => request<Task[]>('/api/tasks'),
  activeTasks: () => request<ActiveTask[]>('/api/tasks/active'),
  allocations: () => request<Array<Record<string, unknown>>>('/api/allocations'),
  metrics: () => request<Metrics>('/api/metrics'),
  activities: () => request<Array<{ type: string; message: string; occurred_at: string }>>('/api/activities'),
  alerts: () => request<Array<Record<string, unknown>>>('/api/alerts')
}
