import React, { useEffect, useState } from 'react'
import { createRoot } from 'react-dom/client'
import { AppLayout } from './layouts/AppLayout'
import { Dashboard } from './pages/Dashboard'
import { DevicesPage, EdgeNodesPage, TasksPage, AllocationsPage, SchedulingPage, PerformancePage, AlertsPage, ReportsPage, SettingsPage } from './pages/DataPages'
import { api } from './services/api'
import type { Configuration, EdgeNode, Metrics, Status, Task, ActiveTask } from './types/api'
import './styles.css'

function App(){
  const [page,setPage]=useState('Dashboard'); const [status,setStatus]=useState<Status|null>(null); const [config,setConfig]=useState<Configuration|null>(null); const [edges,setEdges]=useState<EdgeNode[]>([]); const [tasks,setTasks]=useState<Task[]>([]); const [active,setActive]=useState<ActiveTask[]>([]); const [metrics,setMetrics]=useState<Metrics|null>(null); const [activities,setActivities]=useState<Array<{message:string;occurred_at:string}>>([]); const [alerts,setAlerts]=useState<Array<Record<string,unknown>>>([]); const [error,setError]=useState('')
  const refresh=async()=>{try{const [s,c,e,t,a,m,ac,al]=await Promise.all([api.status(),api.configuration(),api.edgeNodes(),api.tasks(),api.activeTasks(),api.metrics(),api.activities(),api.alerts()]);setStatus(s);setConfig(c);setEdges(e);setTasks(t);setActive(a);setMetrics(m);setActivities(ac);setAlerts(al);setError('')}catch(e){setError(e instanceof Error?e.message:'Backend unavailable');setStatus(null)}}
  useEffect(()=>{refresh();const id=setInterval(refresh,1000);return()=>clearInterval(id)},[])
  useEffect(()=>{if(status){document.getElementById('side-devices')!.textContent=String(status.devices);document.getElementById('side-edges')!.textContent=String(status.edge_nodes);document.getElementById('side-tasks')!.textContent=status.tasks_generated.toLocaleString();document.getElementById('side-active')!.textContent=String(status.active_tasks)}},[status])
  let content:React.ReactNode
  if(page==='Dashboard') content=<Dashboard status={status} config={config} edges={edges} tasks={tasks} activeTasks={active} metrics={metrics} activities={activities} alerts={alerts} onConfig={c=>{setConfig(c);refresh()}} onError={setError}/>
  else if(page==='Devices') content=<DevicesPage/>; else if(page==='Edge Nodes') content=<EdgeNodesPage/>; else if(page==='Tasks') content=<TasksPage/>; else if(page==='Allocations') content=<AllocationsPage/>; else if(page==='Scheduling') content=<SchedulingPage/>; else if(page==='Performance') content=<PerformancePage/>; else if(page==='Alerts') content=<AlertsPage/>; else if(page==='Reports') content=<ReportsPage/>; else content=<SettingsPage/>
  return <><AppLayout page={page} setPage={setPage} backendOnline={!!status?.backend_available}>{error && <div className="toast-error">{error}</div>}{content}</AppLayout></>
}
createRoot(document.getElementById('root')!).render(<React.StrictMode><App/></React.StrictMode>)
