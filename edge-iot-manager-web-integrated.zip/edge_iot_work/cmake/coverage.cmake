# ---------------------------------------------------------------------------
# Code coverage report generation.
#
# Only included when -DENABLE_COVERAGE=ON (see top-level CMakeLists.txt),
# which adds --coverage instrumentation to edge_iot_core and the test
# binary. This file adds the `coverage` target that runs the test suite
# and turns the resulting .gcda/.gcno files into a human-readable report.
#
# Usage:
#   cmake -B build-coverage -DCMAKE_BUILD_TYPE=Debug -DENABLE_COVERAGE=ON
#   cmake --build build-coverage -j$(nproc)
#   cmake --build build-coverage --target coverage
#   xdg-open build-coverage/coverage_report/index.html   # (or `open` on macOS)
#
# Prefers lcov+genhtml (richer HTML report); falls back to gcovr if lcov
# isn't installed.
# ---------------------------------------------------------------------------

find_program(LCOV_EXECUTABLE lcov)
find_program(GENHTML_EXECUTABLE genhtml)
find_program(GCOVR_EXECUTABLE gcovr)

set(COVERAGE_OUTPUT_DIR ${CMAKE_BINARY_DIR}/coverage_report)

if(LCOV_EXECUTABLE AND GENHTML_EXECUTABLE)
    message(STATUS "Found lcov + genhtml — 'coverage' target will produce an HTML report.")

    add_custom_target(coverage
        # Zero out any counters from a previous run.
        COMMAND ${LCOV_EXECUTABLE} --directory ${CMAKE_BINARY_DIR} --zerocounters

        # Run the test suite to generate .gcda files.
        COMMAND ${CMAKE_CTEST_COMMAND} --output-on-failure

        # Capture coverage data.
        COMMAND ${LCOV_EXECUTABLE}
                --directory ${CMAKE_BINARY_DIR}
                --capture
                --output-file ${CMAKE_BINARY_DIR}/coverage_raw.info
                --rc lcov_branch_coverage=1

        # Strip out system headers, fetched GoogleTest sources, and the
        # test files themselves — we want coverage OF the project's
        # src/, not of its test harness or dependencies.
        COMMAND ${LCOV_EXECUTABLE}
                --remove ${CMAKE_BINARY_DIR}/coverage_raw.info
                '/usr/*' '*/tests/*' '*_deps/*' '*/third_party/*'
                --output-file ${CMAKE_BINARY_DIR}/coverage_filtered.info
                --rc lcov_branch_coverage=1

        COMMAND ${GENHTML_EXECUTABLE}
                ${CMAKE_BINARY_DIR}/coverage_filtered.info
                --output-directory ${COVERAGE_OUTPUT_DIR}
                --branch-coverage
                --title "Edge IoT Simulator Coverage"

        COMMAND ${CMAKE_COMMAND} -E echo ""
        COMMAND ${CMAKE_COMMAND} -E echo "Coverage report: ${COVERAGE_OUTPUT_DIR}/index.html"

        WORKING_DIRECTORY ${CMAKE_BINARY_DIR}
        DEPENDS edge_iot_tests
        COMMENT "Running tests and generating lcov/genhtml coverage report"
        VERBATIM
    )

elseif(GCOVR_EXECUTABLE)
    message(STATUS "lcov/genhtml not found; falling back to gcovr for the 'coverage' target.")

    add_custom_target(coverage
        COMMAND ${CMAKE_CTEST_COMMAND} --output-on-failure
        COMMAND ${CMAKE_COMMAND} -E make_directory ${COVERAGE_OUTPUT_DIR}
        COMMAND ${GCOVR_EXECUTABLE}
                --root ${CMAKE_SOURCE_DIR}
                --filter ${CMAKE_SOURCE_DIR}/src
                --filter ${CMAKE_SOURCE_DIR}/include
                --exclude ${CMAKE_SOURCE_DIR}/tests
                --exclude ${CMAKE_SOURCE_DIR}/third_party
                --html --html-details
                --output ${COVERAGE_OUTPUT_DIR}/index.html
                --print-summary
                ${CMAKE_BINARY_DIR}
        WORKING_DIRECTORY ${CMAKE_BINARY_DIR}
        DEPENDS edge_iot_tests
        COMMENT "Running tests and generating gcovr coverage report"
        VERBATIM
    )

else()
    message(WARNING
        "ENABLE_COVERAGE is ON but neither lcov+genhtml nor gcovr was found. "
        "The 'coverage' target will not be available. Install one of: "
        "  sudo apt-get install lcov          (recommended, richer HTML)"
        "  sudo apt-get install gcovr         (lighter alternative)")
endif()
